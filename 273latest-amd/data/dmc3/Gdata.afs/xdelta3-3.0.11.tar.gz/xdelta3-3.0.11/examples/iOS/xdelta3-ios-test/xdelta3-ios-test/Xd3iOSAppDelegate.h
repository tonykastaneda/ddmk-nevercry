//
//  Xd3iOSAppDelegate.h
//  xdelta3-ios-test
//
//  Created by Joshua MacDonald on 6/16/12.
//  Copyright (c) 2011, 2012 Joshua MacDonald. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Xd3iOSAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
